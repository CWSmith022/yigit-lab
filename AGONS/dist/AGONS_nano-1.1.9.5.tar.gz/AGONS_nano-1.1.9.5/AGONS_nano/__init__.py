# %%
from AGONS_nano.AGONSModule import AGONS
from AGONS_nano.Custom_Transformers import RowMinMaxScaler, RowStandardScaler