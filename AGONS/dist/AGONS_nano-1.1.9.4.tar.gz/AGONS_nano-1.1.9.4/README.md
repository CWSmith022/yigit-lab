Package to use Yigit Lab Developed AGONS Algorithm for nanoparticle based sensor arrays.

The AGONSModule.py is the main component of the package which utilizes the AGONS functionality.

The Custom_Transformers.py possess two custom transformer tools for row-wise scaling based on sklearn capabilities.

The test.py is a test file for the Custom_Transformers.py.
