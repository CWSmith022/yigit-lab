# %%
from AGONS.AGONSModule import AGONS
from AGONS.Custom_Transformers import RowMinMaxScaler, RowStandardScaler